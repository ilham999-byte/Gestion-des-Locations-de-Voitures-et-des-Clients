package com.example.Gestion.des.Locations.de.Voitures.et.des.Clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDesLocationsDeVoituresEtDesClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
