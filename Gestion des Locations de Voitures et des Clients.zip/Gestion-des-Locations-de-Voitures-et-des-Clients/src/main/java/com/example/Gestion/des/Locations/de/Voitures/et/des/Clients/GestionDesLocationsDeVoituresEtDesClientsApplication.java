package com.example.Gestion.des.Locations.de.Voitures.et.des.Clients;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDesLocationsDeVoituresEtDesClientsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDesLocationsDeVoituresEtDesClientsApplication.class, args);
	}

}
